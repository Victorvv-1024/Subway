import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Main {
	static DataFrame frame;
	Input in = new Input();

	public static void load(String directory){
	 	frame = DataLoader.subwayMap(directory);
	 }

	 private Set<String> listToSet(List<String> list){
		Set<String> set = new HashSet<>();
		for (String a : list){
			if (!set.contains(a)){
				set.add(a);
			}
		}
		return set;
	 }

	public <T> List<T> intersection(List<T> list1, List<T> list2) {
		List<T> list = new ArrayList<T>();

		for (T t : list1) {
			if(list2.contains(t)) {
				list.add(t);
			}
		}

		return list;
	}

	private String select(int number){
		String result = "";
		switch (number){
			case 1:
				result = "subwayShanghai.txt";
				break;
			case 2:
				result = "subwayBeijing.txt";
				break;
		}
		return result;
	}

	public String demandNames(String info){
		Input in = new Input();
		System.out.println("Please give the " + info);
		return in.nextLine();
	}

	private String getOption(){
		System.out.println("We have 2 options: 1) Shanghai 2) Beijing. Please enter one as you need!");
		int number = 1; //default value
		String result = "";
		while(true){
			if (in.hasNextInt()){
				number = in.nextInt();
				if (number == 1 || number == 2){
					result = select(number);
					break;
				}
			}
			in.nextLine();
			System.out.println("Please give a valid input! (1 or 2 ONLY)");
		}
		return result;
	}

	public static List<String> getLineName(Station station) {
		List<String> r = new ArrayList<>();
		for (SubwayLine line : frame.getLines()){
			for (Station s : line.stations){
				if (s.equals(station)){
					r = s.getLines();
				}
			}
		}
		return r;
	}

	public static String getLine(Station station){
		for (Station s : frame.getStations()){
			if (s.equals(station))
				return s.getLine();
		}
		return "";
	}

	public void run(){
	 	load(getOption());
		String start = demandNames("start station.");
		String dest = demandNames("destination.");
		String str = "";
		Result r = Dijksra.calculate(new Station(start),new Station(dest));
		System.out.println("---".repeat(15));
		Station startStation = r.getStartStation();
		Set<String> lineName = listToSet(getLineName(startStation));
		String line = getLine(r.getStartStation());
		str += "Take " + line + "\n";
		str += "The start station is: " + r.getStartStation().name + "\n";
		for (int i = 0; i < r.getPassStations().size(); i++){
			if (r.getPassStations().get(i).isTransfer){
				str += r.getPassStations().get(i).name + "\n";
				if (i != r.getPassStations().size()-1 && (!lineName.equals(getLineName(r.getPassStations().get(i))))){
					Set<String> cur = listToSet(getLineName(r.getPassStations().get(i)));
					Set<String> lineNames = listToSet(getLineName(r.getPassStations().get(i+1)));
//					if (getLine(r.getPassStations().get(i)) == getLine(r.getPassStations().get(i+1))){
//						lineNames.removeAll(cur);
//					}
					lineNames.retainAll(cur);
					lineNames.remove(line);
					if (i + 2 < r.getPassStations().size()){
						List<String> nextLineNames = getLineName(r.getPassStations().get(i+2));
						lineNames.retainAll(nextLineNames);
					}

					if (!lineNames.isEmpty()){
						str += "(Transfer to " + lineNames.toString().replace("[","").replace("]","") + ")\n";
						lineName = lineNames;
						line = getLine(r.getPassStations().get(i+1));
					}
				}
			}
			else{
				str += r.getPassStations().get(i).name + "\n";
			}
		}
		System.out.print(str);
		System.out.println("---".repeat(15));
		System.out.println("Passes " + r.getPassStations().size() + " Stations.");
	}


	public static void main(String[] args) {
		new Main().run();
	}
}
