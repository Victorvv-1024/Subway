import java.util.List;
import java.util.ArrayList;
public class DataFrame {
    private List<Station> stations = new ArrayList<>();
    private List<SubwayLine> lines = new ArrayList<>();

    public DataFrame(){

    }

    public void addStation(Station station){
        this.stations.add(station);
    }
    public List<Station> getStations(){
        return this.stations;
    }

    public void addLine(SubwayLine line){
        this.lines.add(line);
    }
    public List<SubwayLine> getLines(){
        return this.lines;
    }
}
