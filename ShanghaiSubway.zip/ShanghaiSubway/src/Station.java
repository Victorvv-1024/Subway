import java.awt.*;
import java.util.List;
import java.util.ArrayList;
public class Station {
    public String name;
    public String line;
    List<String> lines = new ArrayList<>();
    Boolean isTransfer;

    public Station(){

    }

    public Station(String name){
        this.name = name;
    }

    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }

    public String getLine(){
        return this.line;
    }
    public void setLine(String line){
        this.line = line;
    }

    public Boolean getIsTransfer(){
        return this.isTransfer;
    }
    public void setIsTransfer(Boolean isTransfer){
        this.isTransfer = isTransfer;
    }

    public List<String> getLines(){
        this.lines.add(line);
        return this.lines;
    }
    public void setLines(List<String> lines){
        this.lines = lines;
    }

    public boolean equals(Object obj) {
        if(this == obj)
            return true;
        else if(obj instanceof Station){
            Station s = (Station)obj;
            if(s.getName().equals(this.getName()))
                return true;
            else
                return false;
        }
        else
            return false;
    }

    public int hashCode() {
        return this.getName().hashCode();
    }

}
