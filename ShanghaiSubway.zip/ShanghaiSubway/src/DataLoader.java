import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class DataLoader {
    static DataFrame frame;

    public static DataFrame subwayMap(String f) {
        frame = new DataFrame();
        try (FileReader r = new FileReader(f);
             BufferedReader br = new BufferedReader(r)
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] tokens = line.split(":", 2);
                SubwayLine sl = new SubwayLine();
                sl.name = tokens[0];
                String[] tokens2 = tokens[1].split(" ");
                for(String s: tokens2) {
                    Boolean isTransfer = s.contains("#");
                    Station station = new Station();
                    if(isTransfer) {
                        station.isTransfer = true;
                        String[] tokens3 = s.split("#");
                        station.name = tokens3[0];
                        for(int i = 1; i < tokens3.length; i++) {
                            if (tokens3[i].equals("1"))
                                station.lines.add("1号线");
                            else if (tokens3[i].equals("2"))
                                station.lines.add("2号线");
                            else if (tokens3[i].equals("3"))
                                station.lines.add("3号线");
                            else if (tokens3[i] == "4")
                                station.lines.add("4号线");
                            else if (tokens3[i] == "5号支线")
                                station.lines.add("5号支线");
                            else if (tokens3[i] == "5号线")
                                station.lines.add("5号线");
                            else if (tokens3[i] == "6")
                                station.lines.add("6号线");
                            else if (tokens3[i] == "7")
                                station.lines.add("7号线");
                            else if (tokens3[i] == "8")
                                station.lines.add("8号线");
                            else if (tokens3[i] == "浦江")
                                station.lines.add("浦江线");
                            else if (tokens3[i] == "9")
                                station.lines.add("9号线");
                            else if (tokens3[i] == "磁悬浮")
                                station.lines.add("磁悬浮");
                            else if (tokens3[i] == "航")
                                station.lines.add("10号线(龙溪路-航中路)");
                            else if (tokens3[i] == "虹")
                                station.lines.add("10号线(龙溪路-虹桥火车站)");
                            else if (tokens3[i] == "10")
                                station.lines.add("10号线(新江湾城—龙溪路)");
                            else if (tokens3[i] == "嘉")
                                station.lines.add("11号线(嘉定北-嘉定新城)");
                            else if (tokens3[i] == "花")
                                station.lines.add("11号线(花桥-嘉定新城)");
                            else if (tokens3[i] == "11")
                                station.lines.add("11号线(迪士尼—嘉定新城)");
                            else if (tokens3[i] == "12")
                                station.lines.add("12号线");
                            else if (tokens3[i] == "13")
                                station.lines.add("13号线");
                            else if (tokens3[i] == "16")
                                station.lines.add("16号线");
                            else if (tokens3[i] == "17")
                                station.lines.add("17号线");
                            else if (tokens3[i] == "浦江")
                                station.lines.add("浦江线");
                            else if(tokens3[i].equals("8北"))
                                station.lines.add("8号线北");
                            else if(tokens3[i].equals("8南"))
                                station.lines.add("8号线南");
                            else if(tokens3[i].equals("14西"))
                                station.lines.add("14号线西");
                            else if(tokens3[i].equals("14东"))
                                station.lines.add("14号线东");
                            else if(tokens3[i].equals("八通"))
                                station.lines.add("八通线");
                            else if(tokens3[i].equals("房山"))
                                station.lines.add("房山线");
                            else if(tokens3[i].equals("昌平"))
                                station.lines.add("昌平线");
                            else if(tokens3[i].equals("亦庄"))
                                station.lines.add("亦庄线");
                            else if(tokens3[i].equals("燕房"))
                                station.lines.add("燕房线");
                            else if(tokens3[i].equals("S1"))
                                station.lines.add("S1线");
                            else if(tokens3[i].equals("西郊"))
                                station.lines.add("西郊线");
                            else if(tokens3[i].equals("首都机场"))
                                station.lines.add("首都机场线");
                        }
                        station.line = tokens[0];
                        frame.addStation(station);
                        sl.stations.add(station);
                    }
                    else {
                        if(s.contains("!"))
                            continue;
                        station.isTransfer = false;
                        station.name = s;
                        station.line = tokens[0];
                        frame.addStation(station);
                        sl.stations.add(station);
                    }
                }
                frame.addLine(sl);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return frame;
    }
}
